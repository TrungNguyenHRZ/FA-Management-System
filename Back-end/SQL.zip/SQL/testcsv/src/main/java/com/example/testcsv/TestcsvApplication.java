package com.example.testcsv;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TestcsvApplication {

	public static void main(String[] args) {
		SpringApplication.run(TestcsvApplication.class, args);
	}

}
